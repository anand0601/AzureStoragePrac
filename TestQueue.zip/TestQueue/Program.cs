﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;


namespace TestQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var connection = "Endpoint=sb://az70532testbus1.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=MSeDBiIEE7oo7mZ8mKTPRqeeDT0F72BjwO5743HUj3o=";
                var queue = "az70532testqueue";
                var topic = "az70532testtopic";

                var client = QueueClient.CreateFromConnectionString(connection, queue);
                var topicClient = TopicClient.CreateFromConnectionString(connection, topic);
                


                var nsm = NamespaceManager.CreateFromConnectionString(connection);

                if (!nsm.SubscriptionExists(topic, "AllMessages"))
                {
                    nsm.CreateSubscription(topic,"AllMessages");
                }

                var subClient = SubscriptionClient.CreateFromConnectionString(connection, topic, "AllMessages");

                ReadTopic(subClient);

                

            }
            catch (Exception ex)
            {
                var m = ex.Message;
            }


            Console.ReadKey();
        }

        static void ReadWriteQueue(QueueClient client)
        {
            var msg = new BrokeredMessage("Hello again  from the test program");
            client.Send(msg);

            //Read msg in queue
            client.OnMessage(message =>
            {
                Console.WriteLine("Message: " + message.GetBody<string>());
            });
        }

        static void WriteTopic(TopicClient client)
        {
            var msg = new BrokeredMessage("This is a Topic Message");
            client.Send(msg);

           
        }

        static void ReadTopic(SubscriptionClient client)
        {
            

            OnMessageOptions options = new OnMessageOptions();
            options.AutoComplete = false;

            client.OnMessage(message =>
            {
                Console.WriteLine("Message: " + message.GetBody<string>());
                message.Complete();
            },options);

        }
    }
}
