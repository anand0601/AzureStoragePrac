﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.Shared.Protocol;


namespace Blobs
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                string stroageConnection = System.Configuration.ConfigurationManager.AppSettings.Get("StorageConnectionString");
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(stroageConnection);

                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

                //CloudBlobContainer container = blobClient.GetContainerReference("objective2");

                //container.CreateIfNotExists();

                //ListAttributes(container);

                //SetMetaData(container);

                //ListMetaData(container);

                //CopyBlob(container);

                //UploadBlobSubDirectory(container);

                CreateCORSPolicy(blobClient);

                var blobName = new Uri("",)

                Console.ReadKey();
            }
            catch(Exception ex)
            {
                string s = ex.ToString();
            }
        }

       

        static void UploadBlob(CloudBlobContainer container)
        {
            CloudBlockBlob blockBlob = container.GetBlockBlobReference("examObjectives");

            using (var fileStream = System.IO.File.OpenRe ad(@"C:\Users\we624\Downloads\Mendix Training Terms and Privacy Policy Feb 2013.pdf"))
            {
                blockBlob.UploadFromStream(fileStream);
            }
        }

        static void ListAttributes(CloudBlobContainer container)
        {
            container.FetchAttributes();

            Console.WriteLine("Container Name " + container.StorageUri.PrimaryUri.ToString());
            Console.WriteLine("Container Name " + container.Properties.LastModified.ToString());
        }

        static void SetMetaData(CloudBlobContainer container)
        {
            container.Metadata.Clear();
            container.Metadata.Add("author", "Anand Sharma");
            container.Metadata["authoredOn"] = "Sep 11, 2017";

            container.SetMetadata();
        }

        static void ListMetaData(CloudBlobContainer container)
        {
            
            container.FetchAttributes();

            Console.WriteLine("Metadata: " + "\n");
            foreach (var item in container.Metadata)
            {
                Console.WriteLine("Key " + item.Key);
                Console.WriteLine("Value " + item.Value + "\n\n");


            }
        }

        static void CopyBlob(CloudBlobContainer container)
        {
            CloudBlockBlob blockBlob = container.GetBlockBlobReference("examObjectives");
            CloudBlockBlob copyToBlockBLob = container.GetBlockBlobReference("examObjectives-copy");
            copyToBlockBLob.StartCopyAsync(blockBlob);

        }

        static void UploadBlobSubDirectory(CloudBlobContainer container)
        {
            CloudBlobDirectory directory = container.GetDirectoryReference("parent-directory");
            CloudBlobDirectory subdirectory = directory.GetDirectoryReference("sub-directory");

            CloudBlockBlob blockblob = subdirectory.GetBlockBlobReference("new-examObjectives");

            using (var fileStream = System.IO.File.OpenRead(@"C:\Users\we624\Downloads\Mendix Training Terms and Privacy Policy Feb 2013.pdf"))
            {
                blockblob.UploadFromStream(fileStream);

                blockblob.DownloadRangeToStream()
            }
        }

        static void CreateSharedAccessPolicy(CloudBlobContainer container)
        {
            SharedAccessBlobPolicy sharedPolicy = new SharedAccessBlobPolicy()
            {
                SharedAccessExpiryTime = DateTime.UtcNow.AddHours(24),
                Permissions = SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Write | SharedAccessBlobPermissions.List 
                
            };


            BlobContainerPermissions permission = new BlobContainerPermissions();

            permission.SharedAccessPolicies.Clear();
            permission.SharedAccessPolicies.Add("SharedAccessPolicyName", sharedPolicy);
            container.SetPermissions(permission);
            //string SAStoken = container.GetSharedAccessSignature(sharedPolicy);


        }

        static void CreateCORSPolicy(CloudBlobClient blobClient)
        {
            ServiceProperties sp = new ServiceProperties();
            sp.Cors.CorsRules.Add(new CorsRule()
            {
                AllowedMethods = CorsHttpMethods.Get,
                AllowedOrigins = new List<string>() { "http://localhost:8080/" },
                MaxAgeInSeconds = 3600,
            });
            blobClient.SetServiceProperties(sp);
        }

    }
}
