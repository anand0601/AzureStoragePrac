﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Queue;

namespace Tables
{
    class Program
    {
        static void Main(string[] args)
        {
            string stroageConnection = System.Configuration.ConfigurationManager.AppSettings.Get("StorageConnectionString");
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(stroageConnection);

            //Table

            //CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            //CloudTable table = tableClient.GetTableReference("FirstTestTable");
            //table.CreateIfNotExists();

            //TableOperation retrieve = TableOperation.Retrieve<CarEntity>("car", "123");
            //TableResult result =  table.Execute(retrieve);

            //if (result.Result == null)
            //{
            //    Console.WriteLine("not found");
            //}
            //else
            //{
            //    Console.WriteLine("found the car : " + ((CarEntity)result.Result).Make + " " + ((CarEntity)result.Result).Model);
            //}



            //TableQuery<CarEntity> carquery = new TableQuery<CarEntity>();
            //foreach (CarEntity thisCar in table.ExecuteQuery(carquery))
            //{
            //    Console.WriteLine(thisCar.Year + " " + thisCar.Make + " " + thisCar.Model + " " + thisCar.Color);
            //}



            //Queue
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            CloudQueue myQueue = queueClient.GetQueueReference("thisisaqueue");
            myQueue.CreateIfNotExists();

            //CloudQueueMessage newmessage = new CloudQueueMessage("This is a desperate cry for help!");
            //myQueue.AddMessage(newmessage);

            //CloudQueueMessage newmessage = new CloudQueueMessage("This is a fourth message!");
            //myQueue.AddMessage(newmessage);

            //reading message
            CloudQueueMessage oldmessage = myQueue.GetMessage(new TimeSpan(0,5,0));
            Console.WriteLine(oldmessage.AsString);

            Console.ReadKey();


        }

        static void Insert(CloudStorageAccount stoarageAccount, CloudTable table)
        {
            CarEntity newCar = new CarEntity(123, 2011, "BMW", "X1", "Black");
            TableOperation insert = TableOperation.Insert(newCar);
            table.Execute(insert);

            newCar = new CarEntity(124, 2010, "BMW", "X1", "Black");
            insert = TableOperation.Insert(newCar);
            table.Execute(insert);

            newCar = new CarEntity(125, 2012, "Honda", "Civic", "Silver");
            insert = TableOperation.Insert(newCar);
            table.Execute(insert);

            newCar = new CarEntity(126, 2013, "Toyata", "Camrey", "Grey");
            insert = TableOperation.Insert(newCar);
            table.Execute(insert);

            newCar = new CarEntity(127, 2014, "WW", "T1", "Whilte");
            insert = TableOperation.Insert(newCar);
            table.Execute(insert);

            newCar = new CarEntity(128, 2015, "Lexus", "G1", "Black");
            insert = TableOperation.Insert(newCar);
            table.Execute(insert);


            //TableBatchOperation tbo = new TableBatchOperation();
            //newCar = new CarEntity(123, 2011, "BMW", "X1", "Black");
            //tbo.Insert(newCar);
            //newCar = new CarEntity(124, 2010, "BMW", "X2", "Black");
            //tbo.Insert(newCar);
            //newCar = new CarEntity(125, 2012, "Honda", "Civic", "Silver");
            //tbo.Insert(newCar);
            //table.ExecuteBatch(tbo);

        }

    }

    public class CarEntity : TableEntity
    {
        public CarEntity(int ID,int year, string make, string model, string color)
        {
            this.UniqueID = ID;
            this.Year = year;
            this.Make = make;
            this.Model = model;
            this.Color = color;

            this.PartitionKey = "car";
            this.RowKey = ID.ToString();
        }

        public CarEntity()
        {
        }

        public int UniqueID { get; set; }

        public int Year { get; set; }

        public string Make { get; set; }

        public string Model { get; set; }

        public string  Color { get; set; }
    }
}
